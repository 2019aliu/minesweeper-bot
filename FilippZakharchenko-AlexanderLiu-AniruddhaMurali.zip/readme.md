Team:
Filipp Zakharchenko,
Alexander Liu, 
Aniruddha Murali

Files:

3510-project-S21-v2.1.pdf	minesweeperPerformanceTest.py
Generate.py			readme.md
README				test_board.json
__pycache__			varied_density_ai1.txt
data_analysis.py		varied_density_ai2.txt
deterministic_board.json	varied_density_boards
minesweeperAI1.py		varied_size_ai1.txt
minesweeperAI2.py		varied_size_ai2.txt
minesweeperGameEngine.py	varied_size_boards

Instructions:
Same as with starter code. We used AI1 and AI2 to implement our algorithms.